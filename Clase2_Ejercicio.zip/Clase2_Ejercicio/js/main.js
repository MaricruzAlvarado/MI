//agregar a una clase
function addClasses(...classses) {
    classses.forEach(element => {
        $("div#holaMundo").addClass(element);
    });
}
function setFormat(personas) {
    personas.forEach(element => {
        document.getElementById("personasId").innerHTML +=  
        "<div class='pClass'><p>"+ `${element.id}` +"</p>"+
        "<p>"+ `${element.name}` +"</p>"+
        "<p>"+ `${element.brewery_type}` +"</p>"+
        "<p>"+ `${element.street}` +"</p>"+
        "<p id='c'>"+ `${element.city}` +"</p>"+
        "<p id='c'>"+ `${element.state}` +"</p>"+
        "<p id='c'>"+ `${element.postal_code}` +"</p>"+
        "<p>"+ `${element.country}` +"</p>"+
        "<p>"+ `${element.longitude}` +"</p>"+
        "<p>"+ `${element.latitude}` +"</p>"+
        "<p>"+ `${element.website_url}` +"</p>"+
        "<p>"+ `${element.updated_at}` +"</p></div>";
    });
}
//arrow function
//cntrl k c  comentar
$(document).ready(() => {
    $.ajax({
        url: "mock/data.json"
    }).done(data => {
        //let comment=data["_comment"];
        var personas = data;
        console.info(`Personas: ${personas}`);
        $("#personasId").append(setFormat(personas));
    });
});