export const fragmentShader = `
    precision mediump float;
    void main() {
        vec4 color = vec4(1.0, 1.0, 1.0, 1.0);
        gl_FragColor = color;
    }
  `;
