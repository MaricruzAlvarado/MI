//cargar three.js
const THREE = require("three");

const clock= new THREE.Clock();
const camera = new THREE.PerspectiveCamera(
  65, //campo de vision
  window.innerWidth / window.innerHeight, //aspect
  0.1, //near
  1000 //far
);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(new THREE.Color(0, 0, 0));

document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();

const box = new THREE.BoxGeometry();
const material = new THREE.MeshLambertMaterial({
  color: new THREE.Color(0, 1, 0)
});
const cube = new THREE.Mesh(box, material);


const sphere = new THREE.SphereGeometry();
const material2 = new THREE.MeshPhongMaterial({
  color: new THREE.Color(0, 1, 1)
});
const sph = new THREE.Mesh(sphere, material2);


scene.add(cube);
scene.add(sph);
cube.position.x = -5;
camera.position.z = 10;

const ambiental= new THREE.AmbientLight(
    new THREE.Color(1,1,1),
    0.4
);
scene.add(ambiental);

const directional= new THREE.DirectionalLight(
    new THREE.Color(1,1,1),
    0.4
);
directional.castShadow=true;
scene.add(directional);

const spot= new THREE.SpotLight(
    new THREE.Color(0,1,1),
    0.8
);
spot.position.set(1,1,1);
scene.add(spot);

var camb =false;

var angle=0;
var orbitRadius = 3; // for example
var date;
var pivot = new THREE.Group();
scene.add( pivot );
pivot.add( cube );

const animate = function() {
  requestAnimationFrame(animate);

  //cube.rotation.x +=(1*clock.getDelta());
if(!camb){
    if(sph.position.x<8){
        sph.position.x +=(1);   
      } else{
        camb=true;
      }
}
if(camb){
    if(sph.position.x>-8){
        sph.position.x -=(1);
      }else{
        camb=false;
      }
  }

pivot.rotation.z += .2;

  renderer.render(scene, camera);
};

animate();
